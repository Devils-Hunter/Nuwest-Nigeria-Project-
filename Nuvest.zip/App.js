// In App.js in a new project
import React, { useState, useRef, useEffect } from "react";
import {
    View,
    StyleSheet,
    ImageBackground,
    Text,
    TouchableOpacity,
    Alert,
    AsyncStorage,
    TextInput,
    ScrollView,
    Image,
    TouchableHighlight,
    NativeModules,
} from "react-native";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import Icon from "react-native-vector-icons/AntDesign";
import OTPTextInput from "react-native-otp-textinput";
import OTPInputView from "@twotalltotems/react-native-otp-input";
import { Header, Card,Input,Button } from "react-native-elements";
import { color } from "react-native-reanimated";
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import Modal from 'react-native-modal';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
var Carousel = require("react-native-carousel");
import RazorpayCheckout from 'react-native-razorpay';
import InputOutline from 'react-native-input-outline';
import CountDown from 'react-native-countdown-component';
import PTRView from 'react-native-pull-to-refresh';
import RNRestart from 'react-native-restart';


function HomeScreen({navigation}) {
    return (
        <View style={{ flex: 1,backgroundColor:'#34495e' }}>

            <Text></Text>
            <View style={{flex:0.2,justifyContent: 'flex-end',alignItems:'center'}}>

                <Text style={{fontSize:50,color:'white',fontWeight:'bold',fontFamily:'Roboto-Black'}}>Nuvest</Text>

            </View>

            <Text></Text>

            <View style={{flex:0.5}}>

                <Carousel indicatorOffset={0}>
                    <View style={{flex:1,backgroundColor:'#e67e22',alignItems:'center',justifyContent:'center'}}>
                        <Text style={{color:'white',fontSize:30,fontFamily:'Roboto-Black'}}>#banner1 Images</Text>
                    </View>
                    <View style={{flex:1,backgroundColor:'#3498db',alignItems:'center',justifyContent:'center'}}>
                        <Text style={{color:'white',fontSize:30,fontFamily:'Roboto-Black'}}>#banner2 Images</Text>
                    </View>
                    <View style={{flex:1,backgroundColor:'#9b59b6',alignItems:'center',justifyContent:'center'}}>
                        <Text style={{color:'white',fontSize:30,fontFamily:'Roboto-Black'}}>#banner3 Images</Text>
                    </View>
                </Carousel>
            </View>
           
            <Text></Text>
            <View style={{flex:0.4,alignItems:'center'}}>

                <TouchableOpacity style={{height:80,width:'90%',alignItems:'center',justifyContent:'center',backgroundColor:'#3498db',borderWidth:1,borderColor:'white',borderRadius:28}} onPress={()=>{ alert("You Enter THe Login Button");  }}>
                <Text  style={{color:'white',fontSize:35,fontFamily:'Roboto-Black'}}>Login</Text>
                </TouchableOpacity>

                 <Text></Text>
                
                <TouchableOpacity style={{height:80,width:'90%',alignItems:'center',justifyContent:'center',backgroundColor:'#3498db',borderWidth:1,borderColor:'white',borderRadius:28}} onPress={()=>{ alert("You ENter On the register buttoin")   }  }  >
                <Text  style={{color:'white',fontSize:35,fontFamily:'Roboto-Black'}}>Register</Text>
                </TouchableOpacity>




            </View>





        </View>
    );
}



function userRegistration({ navigation }) {

    const [fullName, setFullName] = useState('');
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');

    function check() {

        if(fullName == ''){
            alert("it is fullName is empty");
        }

        if(userName == ''){
            alert("it is userName is empty");
        }

        if(password == ''){
            alert("it is cofirm  password is empty");
        }
        else{

            AsyncStorage.setItem("fullnamo", fullName);
            AsyncStorage.setItem("usernamo", userName);
            AsyncStorage.setItem("passwordo", password);

            navigation.navigate("otp");

        }


    }





    return (
        <View style={{ flex: 1,backgroundColor:'#222f3e'}}>
            <KeyboardAwareScrollView>
                <Header
                    backgroundColor="#48dbfb"
                    centerComponent={{
                        text: "User Registration",
                        style: { color: "white",fontWeight:'bold', fontSize: 23 },
                    }}
                />
                <View style={[styles.con1,{ marginBottom:30  }]}>
                    <Icon name="idcard" size={150} color="#ecf0f1" />
                </View>


                <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>

                    <Input
                        placeholder='Full Name'
                        inputStyle={{color:'white'}}
                        placeholderTextColor='white'
                        onChangeText={(val)=>setFullName(val)}
                        leftIcon={
                            <Icon
                                name='user'
                                size={24}
                                color='#ecf0f1'
                            />} />

                    <Input
                        placeholder='user-name'
                        onChangeText={(val)=>{ setUserName(val);  }}
                        inputStyle={{color:'white'}}
                        placeholderTextColor='white'
                        leftIcon={
                            <Icon
                                name='meh'
                                size={24}
                                color='#ecf0f1'
                            />} />

                    <Input
                        placeholder='password'
                        placeholderTextColor='white'
                        inputStyle={{color:'white'}}
                        leftIcon={
                            <Icon
                                name='lock'
                                size={24}
                                color='#ecf0f1'
                            />} />

                    <Input
                        placeholder='Confirm password'
                        onChangeText={(val)=>{ setPassword(val);  }}
                        inputStyle={{color:'white'}}
                        placeholderTextColor='white'
                        leftIcon={
                            <Icon
                                name='lock'
                                size={24}
                                color='#ecf0f1'
                            />} />



                    <Text></Text>


                    <TouchableOpacity style={{ marginTop: 20 }} onPress={check}>
                        <Icon name="play" size={60} color="white" />
                    </TouchableOpacity>


                </View>
            </KeyboardAwareScrollView>

        </View>
    );
}


function DeepakLogin({ navigation }) {
    const [name, setName] = useState('');

    function sendsms() {

        AsyncStorage.setItem("number", name);

        var b = Math.floor(Math.random() * 9000) + 1111;

        if(name ==''){
            alert("Please Write No.");
        }
        else
        {

            var otp =
                "https://2factor.in/API/V1/98e33656-f351-11ea-9fa5-0200cd936042/SMS/" +
                name +
                "/" +
                b;

            fetch(otp, {
                method: "GET",
            })
                .then((response) => response.json())
                .then((responseJson) => {
                    navigation.navigate("OtpVeri", { otp: b });
                })
                .catch((error) => {
                    console.log(error);
                });
        }


    }

    return (
        <View style={{ flex: 1,backgroundColor:'#222f3e' }}>
            <Header
                backgroundColor="#48dbfb"
                centerComponent={{
                    text: "OTP Verfication",
                    style: { color: "white",fontWeight:'bold', fontSize: 23 },
                }}
            />

            <View style={styles.con1}>
                <Icon name="phone" size={150} color="white" />
            </View>
            <View style={styles.con2}>
                <TextInput
                    style={{
                        height: 50,
                        width: "90%",
                        fontSize: 20,
                        borderBottomWidth: 1,
                        color:'white',
                        borderColor: "gray",
                    }}
                    value="India(+91)"
                    editable={false}
                />

                <TextInput
                    placeholderTextColor='white'
                    style={{
                        height: 50,
                        width: "90%",
                        fontSize: 20,
                        borderBottomWidth: 1,
                        color:'white',
                        borderColor: "gray",
                    }}
                    placeholder="Phone Number"
                    keyboardType="numeric"
                    onChangeText={(text) => {
                        setName(text);
                    }}
                />

                <Text style={{ color:'white',marginTop: 20 }}>
                    We will send you one time SMS message
                </Text>

                <TouchableOpacity style={{ marginTop: 20 }} onPress={sendsms}>
                    <Icon name="play" size={60} color="white" />
                </TouchableOpacity>
            </View>
        </View>
    );
}

function veri({ navigation, route }) {
    const [otp, setOtp] = useState();
    const [num, setNum] = useState();

    const [name, setName] = useState();
    const [userName, setUserName] = useState();
    const [password, setPassword] = useState();

    const [number, setNumber] = useState();

    useEffect(() => {
        var b = route.params?.otp;
        setNum(b);

        AsyncStorage.getItem("fullnamo").then((value) => {
            setName(value);
        });

        AsyncStorage.getItem("usernamo").then((value) => {
            setUserName(value);
        });

        AsyncStorage.getItem("passwordo").then((value) => {
            setPassword(value);
        });

        AsyncStorage.getItem("number").then((value) => {
            setNumber(value);
        });
    }, []);

    function checko() {
        if (otp == num) {
            navigation.navigate('maino');

        } else {
            alert("You enter The OTP Incoorectly");
        }
    }

    return (
        <View style={{ flex: 1,backgroundColor:'#222f3e'}}>
            <Header
                backgroundColor="#48dbfb"
                centerComponent={{
                    text: "Enter OTP",
                    style: { color: "white",fontWeight:'bold', fontSize: 23 },

                }}
            />

            <View style={styles.con1}>
                <Icon name="phone" size={150} color="white" />
            </View>


            <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                <OTPTextInput
                    handleTextChange={(val) => {
                        setOtp(val);
                    }}
                    textInputStyle={{color:'white'}}
                />
                <Text></Text>
                <TouchableOpacity style={{ marginTop: 15 }} onPress={checko}>
                    <Icon name="play" size={60} color="white" />
                </TouchableOpacity>
            </View>
        </View>
    );
}



function mainPage({navigation}) {



    return (
        <View style={{ flex: 1,backgroundColor:"#222f3e"}}>

            <Text>user Shoping Cart</Text> 



        </View>
    );
}


const Drawer = createDrawerNavigator();
const Tab = createMaterialBottomTabNavigator();
const Stack = createStackNavigator();


function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="profile">
                <Stack.Screen name="Home" options={{headerShown:false}} component={HomeScreen} />
                <Stack.Screen name="userRegi" options={{headerShown:false}} component={userRegistration} />
                <Stack.Screen name="otp" options={{ headerShown: false }} component={DeepakLogin} />
                <Stack.Screen name="OtpVeri" options={{ headerShown: false }} component={veri} />
                <Stack.Screen name="maino" options={{ headerShown: false }} component={mainPage} />









            </Stack.Navigator>
        </NavigationContainer>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "red",
    },

    con1: {
        flex: 0.7,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#48dbfb",
        borderBottomRightRadius: 60,
        borderBottomLeftRadius: 60,
    },
    wrapper: {},
    con2: {
        flex: 1,
        alignItems: "center",
        marginTop: 40,
    },
    text: {
        borderWidth: 2,
        padding: 8,
        fontSize: 20,
        width: "90%",
        marginBottom: 4,
    },
    image: {
        flex: 1,
        resizeMode: "cover",
        justifyContent: "center",
        alignItems: "center",
    },
});


export default App;
